﻿using System;

public class UserLogin
{
	public User()
	{

	public String name;
	public String pass;
	public String fNum;
	public String role;

	}
}
