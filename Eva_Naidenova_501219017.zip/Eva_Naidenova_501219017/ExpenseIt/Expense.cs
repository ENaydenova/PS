﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpenseIt
{
    public class Expense
    {
        public string ExpenseType { get; set; }
        public double ExpenseAmount { get; set; }
    }
}
