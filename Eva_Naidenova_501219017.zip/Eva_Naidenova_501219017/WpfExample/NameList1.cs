﻿namespace WpfExample
{
    internal class NameList
    {
        public object SelectedName { get; internal set; }
        public object Names { get; internal set; }
    }
}